<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>

<?php
	foreach ($view_data as $row) {
		echo form_open();
		echo '</br></br>';
		
		echo 'Publisher ID : ';
		echo form_input('publisherID', $row->PublisherID, 'readonly');
		
		echo '</br></br>Publisher Name : ';
		echo form_input('publisherName', $row->PublisherName, 'readonly');

		echo '</br></br>Address Line 1 : ';
		echo form_input('addressLine1', $row->AddressLine1, 'readonly');

		echo '</br></br>Address Line 2 : ';
		echo form_input('addressLine2', $row->AddressLine2, 'readonly');
		
		echo '</br></br>Address Line 3 : ';
		echo form_input('addressLine3', $row->AddressLine3, 'readonly');
		
		echo '</br></br>Contact Name : ';
		echo form_input('contactName', $row->ContactName, 'readonly');

		echo '</br></br>';
		echo '<img src='.$img_base.'full/'.$row->Image.'>';
		
		echo '</br></br>';
		echo form_close();
	}