<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>

<?php
	foreach ($view_data as $row) {
		echo form_open();
		echo '</br></br>';
		
		echo 'Order Number : ';
		echo form_input('authorID', $row->odOrderNumber, 'readonly');
		
		echo '</br></br>Product Code : ';
		echo form_input('ODProductCode', $row->odProductCode, 'readonly');

		echo '</br></br>Quantity Ordered : ';
		echo form_input('ODQuantityOrdered', $row->odQuantityOrdered, 'readonly');

		echo '</br></br>Price : ';
		echo form_input('ODPrice', $row->odPrice, 'readonly');
		
		echo '</br></br>';
		echo form_close();
	}
	?>