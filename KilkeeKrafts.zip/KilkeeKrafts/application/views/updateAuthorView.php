<?php
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
<br>
<h1 class="main"> Update Author </h1>
<?php 
foreach($edit_data as $row){
	echo form_open_multipart('AuthorController/updateAuthor/'.$row->prodCode);
	echo '</br></br>';
	
	echo 'Enter Prod Code :';
	echo form_input('ProdCode', $row->prodCode, 'readonly');
	
	echo '</br></br>Enter Prod Description :';
	echo form_input('ProdDescription', $row->prodDescription);

	echo '</br></br>Enter Prod Category :';
	echo form_input('ProdCategory', $row->prodCategory);

	echo '</br></br>Enter Prod Artist :';
	echo form_input('ProdArtist', $row->prodArtist);

	echo '</br></br>Enter Prod Qty In Stock :';
	echo form_input('ProdQtyInStock', $row->prodQtyInStock);
	
		echo '</br></br>Enter Prod Buy Cost :';
	echo form_input('ProdBuyCost', $row->prodBuyCost);
	
	echo '</br></br>Enter Prod Sale Price :';
	echo form_input('ProdSalePrice', $row->prodSalePrice);
	
	echo '</br></br>Select File for Upload :'; 
	echo form_upload('userfile');
	
	echo '</br></br>Price Already Discounted :';
	echo form_input('PriceAlreadyDiscounted', $row->priceAlreadyDiscounted);
	
	echo '</br></br>';
	
	echo form_submit('submitUpdate', "Submit!");

	echo form_close();
	echo validation_errors();
}
?>

<?php
	$this->load->view('footer'); 
?>