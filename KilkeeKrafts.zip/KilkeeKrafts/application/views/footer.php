
<div id="footer">
	<p>Copyright (c) 2020 Sharon <a href="http://www.lit.ie">LIT</a></p>
</div>
</body>
</html>
