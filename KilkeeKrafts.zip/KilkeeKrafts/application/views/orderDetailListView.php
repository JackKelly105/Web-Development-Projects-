<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
<div class="list">
	<br><br>
	
	
	<h2>Search Order </h2>
	
	<?php 
   
		echo form_open('orders/SearchOrderDetail');
		
		echo "Enter Order Number: ";
		echo form_input('odOrderNumber');
		
		echo "<br><br>";
		
		echo form_submit("Search", "Search Order!"); 
	?>
		<br><br>
	<h1 class="main">Order Details</h1>
	
	<table>
		<tr>
			<th align="left" width="150">Order Number</th>
			<th align="left" width="180">Product Code</th>
			<th align="left" width="180">Order Quantity</th>
			<th align="left" width="180">Price</th>
			<th align="left" width="180">Action</th>
		</tr>

		<?php foreach($author_info as $row){?>
		<tr>
			<td><?php echo $row->odOrderNumber;?></td>
			<td><?php echo $row->odProductCode;?></td>
			<td><?php echo $row->odQuantityOrdered;?></td>
			<td><?php echo $row->odPrice;?></td>
			<td><?php echo anchor('orders/viewOrderDetails/'.$row->odOrderNumber,'View');?></td>
		</tr>  
			
		<?php }?>  
   </table>
   <br><br>
</div>
<?php
	echo $this->pagination->create_links(); 
?>
<?php
	$this->load->view('footer'); 
?>
