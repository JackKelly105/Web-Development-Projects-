<?php
	$this->load->view('headercust'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
    <div class="main">
		<br><br><br><br>
		<h1>KilKee Krafts DataBase</h1>
		<p>Information about our Products</p>
		<a href=" <?= site_url('CustController/logoutCust') ?> ">Logout</a>
		<br><br><br><br>
	</div>
	
<?php
	$this->load->view('footer'); 
?>