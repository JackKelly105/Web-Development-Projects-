<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	$this->load->view('headercust'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
<div class="list">
	
	
	<br><br>
	<h1 class="main">Shopping Cart</h1>
	
	<table>
		<tr>
			<th align="left" width="150">Prod Code</th>
			<th align="left" width="180">Prod Description</th>
			<th align="left" width="180">Prod Sale Price</th>
			<th align="left" width="180">Prod Photo</th>
			<th align="left" width="180">Quantity</th>
			<th align="left" width="180">Sub Total</th>
			<th align="left" width="180">Action</th>
			<th align="left" width="180">Action</th>
			
			
		</tr>

		<?php foreach ($items as $item){?>
		<tr>
			<td><?php echo $item['prodCode'];?></td>
			<td><?php echo $item['prodDescription'];?></td>
			<td><?php echo $item['prodSalePrice'];?></td>
			<td><img src="<?php echo $img_base.'products/thumbs/'.$item['prodPhoto']?>"></td>
			<td><?php echo $item['quantity']; ?></td>
        			<td><?php echo $item['prodSalePrice'] * $item['quantity']; ?></td>
					<td>
        				<a href="<?php echo site_url('cart/save_order/'.$item['prodCode']); ?>">Place Order</a>
        			</td>
        			<td>
        				<a href="<?php echo site_url('cart/remove/'.$item['prodCode']); ?>">Remove</a>
        			</td>
			
		</tr>  
			
		<?php }?>  
				<tr>
        			<td colspan="6" align="right">Total</td>
        			<td><?php echo $total; ?></td>
        		</tr>
   </table>
   <br><br>
</div>
<?php
	echo $this->pagination->create_links(); 
?>
<?php
	$this->load->view('footer'); 
?>
