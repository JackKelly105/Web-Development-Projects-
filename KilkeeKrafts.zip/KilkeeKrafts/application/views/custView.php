<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	$this->load->view('headercust'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>

<?php
	foreach ($view_data as $row) {
		echo form_open();
		echo '</br></br>';
		
		echo 'Prod Code : ';
		echo form_input('authorID', $row->prodCode, 'readonly');
		
		echo '</br></br>Prod Description : ';
		echo form_input('ProdDescription', $row->prodDescription, 'readonly');

		echo '</br></br>Prod Category : ';
		echo form_input('ProdCategory', $row->prodCategory, 'readonly');

		echo '</br></br>Prod Artist : ';
		echo form_input('ProdArtist', $row->prodArtist, 'readonly');
		
		echo '</br></br>Prod Qty In Stock : ';
		echo form_input('ProdQtyInStock', $row->prodQtyInStock, 'readonly');
		
		echo '</br></br>Prod Buy Cost : ';
		echo form_input('ProdBuyCost', $row->prodBuyCost, 'readonly');
		
		echo '</br></br>Prod Sale Price : ';
		echo form_input('ProdSalePrice', $row->prodSalePrice, 'readonly');

		echo '</br></br>';
		echo '<img src='.$img_base.'products/full/'.$row->prodPhoto.'>';
		
		echo '</br></br>Price Already Discounted : ';
		echo form_input('PriceAlreadyDiscounted', $row->priceAlreadyDiscounted, 'readonly');
		
		echo '</br></br>';
		echo form_close();
	}