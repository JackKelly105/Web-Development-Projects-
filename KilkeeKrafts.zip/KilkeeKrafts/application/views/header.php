<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	$this->load->helper('url'); 
	$cssbase = base_url()."assets/css/";
	$jsbase = base_url()."assets/javascript/";
	$img_base = base_url()."assets/images/";
	$base = base_url() . index_page();
?>

<!DOCTYPE>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>KilKee Krafts</title>
<link href="<?php echo $cssbase . "style.css"?>" rel="stylesheet" type="text/css" media="all" />
<script src="<?php echo $jsbase."common.js"?>"></script>
</head>

<body>
<header>
<a href="<?php echo site_url('AuthorController/index') ;?>">
    <img class="center-image" src="<?php echo $img_base . "site/logo.png"?>" />
</a>
	
    <?= anchor('AuthorController/index', 'Home', 'title="Home"'); ?>
	&nbsp;&nbsp;&nbsp;
	<?= anchor('AuthorController/handleInsert', 'Insert Products', 'title="Insert Products"'); ?>
    &nbsp;&nbsp;&nbsp;
	<?= anchor('AuthorController/listAuthors', 'List of Products', 'title="List of Products"'); ?>
	&nbsp;&nbsp;&nbsp;
	<?= anchor('orders/listAuthors', 'List of Orders', 'title="List of Orders"'); ?>
	&nbsp;&nbsp;&nbsp;
	<?= anchor('orders/listOrderDetails', 'Order Details', 'title="Order Details"'); ?>
	&nbsp;&nbsp;&nbsp;
</header>
