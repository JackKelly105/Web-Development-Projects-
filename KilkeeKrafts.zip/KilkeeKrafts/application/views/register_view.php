<?php
//sessions 2018
//new view for login
	$this->load->view('headerlogin'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <style>
            .text-danger p{
                color: red;
                margin-top: 0;
            }
        </style>
    </head>
    <body>

        <div class="col-lg-4 col-lg-offset-4" >
            <div class="form" >
                <h1 style="font-size: 22px;">Registration form</h1>
               <?php echo form_open('CustController/reg'); ?>
                    <div class="form-group">
                        <div><input type="text" class="form-control" name="custLastName" placeholder="Last Name" value="<?php echo set_value('custLastName'); ?>"></div>
                        <span class="text-danger"><?php echo form_error("custLastName"); ?> </span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="custFirstName" placeholder="First Name"  value="<?php echo set_value('custFirstName'); ?>">
                        <span class="text-danger"><?php echo form_error("custFirstName"); ?> </span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="custPhone" placeholder="Phone" value="<?php echo set_value('custPhone'); ?>">
                        <span class="text-danger"><?php echo form_error("custPhone"); ?> </span>
                    </div>
					<div class="form-group">
                        <input type="text" class="form-control" name="custAddressLine1" placeholder="Address Line 1" value="<?php echo set_value('custAddressLine1'); ?>">
                        <span class="text-danger"><?php echo form_error("custAddressLine1"); ?> </span>
                    </div>
					<div class="form-group">
                        <input type="text" class="form-control" name="custAddressLine2" placeholder="Address Line 2 (optional)" value="<?php echo set_value('custAddressLine2'); ?>">
                        <span class="text-danger"><?php echo form_error("custAddressLine2"); ?> </span>
                    </div>
					<div class="form-group">
                        <input type="text" class="form-control" name="custCity" placeholder="City" value="<?php echo set_value('custCity'); ?>">
                        <span class="text-danger"><?php echo form_error("custCity"); ?> </span>
                    </div>
					<div class="form-group">
                        <input type="text" class="form-control" name="custPostalCode" placeholder="Postal Code (optional)" value="<?php echo set_value('custPostalCode'); ?>">
                        <span class="text-danger"><?php echo form_error("custPostalCode"); ?> </span>
                    </div>
					<div class="form-group">
                        <input type="text" class="form-control" name="custCountry" placeholder="Country" value="<?php echo set_value('custCountry'); ?>">
                        <span class="text-danger"><?php echo form_error("custCountry"); ?> </span>
                    </div>
					<div class="form-group">
                        <input type="text" class="form-control" name="custCreditLimit" placeholder="Credit Limit (optional)" value="<?php echo set_value('custCreditLimit'); ?>">
                        <span class="text-danger"><?php echo form_error("custCreditLimit"); ?> </span>
                    </div>
					<div class="form-group">
                        <input type="text" class="form-control" name="custEmail" placeholder="Email" value="<?php echo set_value('custEmail'); ?>">
                        <span class="text-danger"><?php echo form_error("custEmail"); ?> </span>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" name="custPassword" placeholder="Password">
                        <span class="text-danger"><?php echo form_error("custPassword"); ?> </span>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" name="confirm_password" placeholder="Confirm Password"  >
                        <span class="text-danger"><?php echo form_error("confirm_password"); ?> </span>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-info" value="Register" name="insert" style="width: 100%;"/>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>

