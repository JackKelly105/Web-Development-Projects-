<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
<div class="list">
	<br><br>
	
	
	<h2>Search Products</h2>
	
	<?php 
   
		echo form_open('AuthorController/Search');
		
		echo "Enter Product Code: ";
		echo form_input('prodCode');
		
		echo "<br><br>";
		
		echo form_submit("Search", "Search Product!"); 
	?>
		<br><br>
	<h1 class="main">List of Products</h1>
	
	<table>
		<tr>
			<th align="left" width="150">Prod Code</th>
			<th align="left" width="180">Prod Description</th>
			<th align="left" width="180">Prod Category</th>
			<th align="left" width="180">Prod Artist</th>
			<th align="left" width="180">Prod Qty In Stock</th>
			<th align="left" width="180">Prod Buy Cost</th>
			<th align="left" width="180">Prod Sale Price</th>
			<th align="left" width="180">Prod Photo</th>
			<th align="left" width="180">Price Already Discounted</th>
			<th align="left" width="180">Action</th>
			<th align="left" width="180">Action</th>
			<th align="left" width="180">Action</th>
		</tr>

		<?php foreach($author_info as $row){?>
		<tr>
			<td><?php echo $row->prodCode;?></td>
			<td><?php echo $row->prodDescription;?></td>
			<td><?php echo $row->prodCategory;?></td>
			<td><?php echo $row->prodArtist;?></td>
			<td><?php echo $row->prodQtyInStock;?></td>
			<td><?php echo $row->prodBuyCost;?></td>
			<td><?php echo $row->prodSalePrice;?></td>
			<td><img src="<?php echo $img_base.'products/thumbs/'.$row->prodPhoto;?>"></td>
			<td><?php echo $row->priceAlreadyDiscounted;?></td>
			<td><?php echo anchor('AuthorController/viewAuthor/'.$row->prodCode,'View');?>
			<td><?php echo anchor('AuthorController/deleteAuthor/'.$row->prodCode,
				'Delete', 'onclick="return checkDelete()"');?></td>
				<td><?php echo anchor('AuthorController/editAuthor/'.$row->prodCode,
				'Update');?></td>
		</tr>  
			
		<?php }?>  
   </table>
   <br><br>
</div>
<?php
	echo $this->pagination->create_links(); 
?>
<?php
	$this->load->view('footer'); 
?>
