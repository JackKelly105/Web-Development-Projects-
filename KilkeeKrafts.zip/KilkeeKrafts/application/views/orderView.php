<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>

<?php
	foreach ($view_data as $row) {
		echo form_open();
		echo '</br></br>';
		
		echo 'Order Number : ';
		echo form_input('authorID', $row->oOrderNumber, 'readonly');
		
		echo '</br></br>Order Date : ';
		echo form_input('OOrderDate', $row->oOrderDate, 'readonly');

		echo '</br></br>Required Date : ';
		echo form_input('ORequiredDate', $row->oRequiredDate, 'readonly');

		echo '</br></br>Shipped Date : ';
		echo form_input('OShippedDate', $row->oShippedDate, 'readonly');
		
		echo '</br></br>Status : ';
		echo form_input('OStatus', $row->oStatus, 'readonly');
		
		echo '</br></br>Comments : ';
		echo form_input('OComments', $row->oComments, 'readonly');
		
		echo '</br></br>Customer Number : ';
		echo form_input('OCustomerNumber', $row->oCustomerNumber, 'readonly');

		echo '</br></br>';
		echo form_close();
	}
	?>