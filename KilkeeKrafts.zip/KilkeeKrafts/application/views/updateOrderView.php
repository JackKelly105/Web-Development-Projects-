<?php
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
<br>
<h1 class="main"> Update Orders </h1>
<?php 
foreach($edit_data as $row){
	echo form_open_multipart('orders/updateAuthor/'.$row->oOrderNumber);
	echo '</br></br>';
	
	echo 'Enter Order Number :';
	echo form_input('OOrderNumber', $row->oOrderNumber, 'readonly');
	
	echo '</br></br>Enter Order Date :';
	echo form_input('OOrderDate', $row->oOrderDate);

	echo '</br></br>Enter Required Date :';
	echo form_input('ORequiredDate', $row->oRequiredDate);

	echo '</br></br>Enter Shipped Date :';
	echo form_input('OShippedDate', $row->oShippedDate);

	echo '</br></br>Enter Status :';
	echo form_input('OStatus', $row->oStatus);
	
		echo '</br></br>Enter Comments :';
	echo form_input('OComments', $row->oComments);
	
	echo '</br></br>Enter Customer Number :';
	echo form_input('OCustomerNumber', $row->oCustomerNumber);

	echo form_submit('submitUpdate', "Submit!");

	echo form_close();
	echo validation_errors();
}
?>

<?php
	$this->load->view('footer'); 
?>