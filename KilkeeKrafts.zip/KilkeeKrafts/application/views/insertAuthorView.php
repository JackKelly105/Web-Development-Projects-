<?php
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
<br>
	<h1>Insert Products</h1>
	<br>
<?php echo form_open_multipart('AuthorController/handleInsert');

	
	echo 'Enter Prod Code :';
	echo form_input('ProdCode', $ProdCode);

	echo '</br></br>Enter Prod Description :';
	echo form_input('ProdDescription', $ProdDescription);

	echo '</br></br>Enter Prod Category :';
	echo form_input('ProdCategory', $ProdCategory);

	echo '</br></br>Enter Prod Artist :';
	echo form_input('ProdArtist', $ProdArtist);

	echo '</br></br>Enter Prod Qty In Stock :';
	echo form_input('ProdQtyInStock', $ProdQtyInStock);
	
	echo '</br></br>Enter Prod Buy Cost :';
	echo form_input('ProdBuyCost', $ProdBuyCost);
	
	echo '</br></br>Enter Prod Sale Price :';
	echo form_input('ProdSalePrice', $ProdSalePrice);
	
	
	echo '</br></br>Select File for Upload :'; 
	echo form_upload('userfile');
	
	echo '</br></br>Price Already Discounted :';
	echo form_input('PriceAlreadyDiscounted', $PriceAlreadyDiscounted);
	
	echo '</br></br>';
	
	echo form_submit('submitInsert', "Submit!");

	echo form_close();
	echo validation_errors();
?>

<?php
	$this->load->view('footer'); 
?>
