<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
<div class="list">
	<br><br>
	
	
	<h2>Search Orders</h2>
	
	<?php 
   
		echo form_open('orders/Search');
		
		echo "Enter Order Number: ";
		echo form_input('oOrderNumber');
		
		echo "<br><br>";
		
		echo form_submit("Search", "Search Order!"); 
	?>
		<br><br>
	<h1 class="main">List of Products</h1>
	
	<table>
		<tr>
			<th align="left" width="150">Order Number</th>
			<th align="left" width="180">Order Date</th>
			<th align="left" width="180">Required Date</th>
			<th align="left" width="180">Shipped Date</th>
			<th align="left" width="180">Status</th>
			<th align="left" width="180">Comments</th>
			<th align="left" width="180">Customer Number</th>
			<th align="left" width="180">Action</th>
			<th align="left" width="180">Action</th>
			<th align="left" width="180">Action</th>
		</tr>

		<?php foreach($author_info as $row){?>
		<tr>
			<td><?php echo $row->oOrderNumber;?></td>
			<td><?php echo $row->oOrderDate;?></td>
			<td><?php echo $row->oRequiredDate;?></td>
			<td><?php echo $row->oShippedDate;?></td>
			<td><?php echo $row->oStatus;?></td>
			<td><?php echo $row->oComments;?></td>
			<td><?php echo $row->oCustomerNumber;?></td>
			<td><?php echo anchor('orders/viewAuthor/'.$row->oOrderNumber,'View');?>
			<td><?php echo anchor('orders/deleteAuthor/'.$row->oOrderNumber,
				'Delete', 'onclick="return checkDelete()"');?></td>
				<td><?php echo anchor('orders/editAuthor/'.$row->oOrderNumber,
				'Update');?></td>
		</tr>  
			
		<?php }?>  
   </table>
   <br><br>
</div>
<?php
	echo $this->pagination->create_links(); 
?>
<?php
	$this->load->view('footer'); 
?>
