<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
<div class="list">
	<br><br>
	<h1 class="main">List of Publishers</h1>
	<br><br>
	<table>
		<tr>
			<th align="left" width="100">ID</th>
			<th align="left" width="150">Name</th>
			<th align="left" width="150">Address Line 1</th>
			<th align="left" width="150">Address Line 2</th>
			<th align="left" width="150">Address Line 3</th>
			<th align="left" width="150">Contact Name</th>
			<th align="left" width="100">Image</th>
			<th align="left" width="100">Action</th>
		</tr>

		<?php foreach($publisher_info as $row){?>
		<tr>
			<td><?php echo $row->PublisherID;?></td>
			<td><?php echo $row->PublisherName;?></td>
			<td><?php echo $row->AddressLine1;?></td>
			<td><?php echo $row->AddressLine2;?></td>
			<td><?php echo $row->AddressLine3;?></td>
			<td><?php echo $row->ContactName;?></td>
			<td><img src="<?php echo $img_base.'thumbs/'.$row->Image;?>"></td>
			<td><?php echo anchor('PublisherController/viewPublisher/'.$row->PublisherID,'View');?></td>
		</tr>     
		<?php }?>  
   </table>
   <br><br>
</div>
<?php
	$this->load->view('footer'); 
?>