<?php
	$this->load->view('headerlogin'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
    <div class="main">
		<br><br><br><br>
		<h1>KilKee Krafts DataBase</h1>
		<p>Information about our Products</p>
		
		<br><br><br><br>
	</div>
	
<?php
	$this->load->view('footer'); 
?>