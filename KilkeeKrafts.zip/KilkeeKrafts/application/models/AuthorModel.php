<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class AuthorModel extends CI_Model {

		function __construct() {
        	parent::__construct();
			$this->load->database();
    	}
	
		function insertAuthorModel($author) {
			$this->db->insert('product',$author);
			if ($this->db->affected_rows() ==1) 
				return true;
			else 
				return false;
		}
		
		function insertOrderModel($author) {
			$this->db->insert('orders',$author);
			if ($this->db->affected_rows() ==1) 
				return true;
			else 
				return false;
		}
		
		function get_all_authors($limit, $offset) {
			$this->db->limit($limit, $offset);
			$this->db->select("prodCode,prodDescription,prodCategory,prodArtist,prodQtyInStock,prodBuyCost,prodSalePrice,prodPhoto,priceAlreadyDiscounted"); 
			$this->db->from('product');
			$query = $this->db->get();
			return $query->result();
		}
		
		function get_all_orders($limit, $offset) {
			$this->db->limit($limit, $offset);
			$this->db->select("oOrderNumber,oOrderDate,oRequiredDate,oShippedDate,oStatus,oComments,oCustomerNumber"); 
			$this->db->from('orders');
			$query = $this->db->get();
			return $query->result();
		}
		
		function get_all_orders_details($limit, $offset) {
			$this->db->limit($limit, $offset);
			$this->db->select("odOrderNumber,odProductCode,odQuantityOrdered,odPrice"); 
			$this->db->from('orderdetail');
			$query = $this->db->get();
			return $query->result();
		}
		
		function deleteAuthorModel($id) {
			
			$this->db->delete('orderdetail', array('odProductCode' => $id));
			$this->db->delete('product', array('prodCode' => $id));
			return true;
		}
		
		function deleteOrderModel($id) {
			
			$this->db->delete('orderdetail', array('odOrderNumber' => $id));
			$this->db->delete('orders', array('oOrderNumber' => $id));
			return true;
		}
		
		function drilldown($author) {
			$this->db->select("prodCode,prodDescription,prodCategory,prodArtist,prodQtyInStock,prodBuyCost,prodSalePrice,prodPhoto,priceAlreadyDiscounted");
			$this->db->from('product');
			$this->db->where('prodCode',$author);
			$query = $this->db->get();
			return $query->result();
		}
		
		function drilldownOrders($author) {
			$this->db->select("oOrderNumber,oOrderDate,oRequiredDate,oShippedDate,oStatus,oComments,oCustomerNumber");
			$this->db->from('orders');
			$this->db->where('oOrderNumber',$author);
			$query = $this->db->get();
			return $query->result();
		}
		
		function drilldownOrderDetails($author) {
			$this->db->select("odOrderNumber,odProductCode,odQuantityOrdered,odPrice");
			$this->db->from('orderdetail');
			$this->db->where('odOrderNumber',$author);
			$query = $this->db->get();
			return $query->result();
		}
		
		function updateAuthorModel($author,$id) {
			$this->db->where('prodCode', $id);
			return $this->db->update('product', $author);
		}
		
		function updateOrdersModel($author,$id) {
			$this->db->where('oOrderNumber', $id);
			return $this->db->update('orders', $author);
		}
		
		function record_count() {
			
			return $this->db->count_all('product');
		}
		
		function record_countOrders() {
			
			return $this->db->count_all('orders');
		}
		
		
		function login($username, $password) {
		$this -> db -> select('adminNumber, adminEmail, adminPassword');
		$this -> db -> from('admins');
		$this -> db -> where('adminEmail', $username);
		$this -> db -> where('adminPassword', MD5($password));
		$this -> db -> limit(1);
		$query = $this -> db -> get();
		if($query -> num_rows() == 1) 
			return $query->result();
	   else
			return false;
	}
	function loginCust($username, $password) {
		$this -> db -> select('custNumber, custEmail, custPassword');
		$this -> db -> from('customer');
		$this -> db -> where('custEmail', $username);
		$this -> db -> where('custPassword', MD5($password));
		$this -> db -> limit(1);
		$query = $this -> db -> get();
		if($query -> num_rows() == 1) 
			return $query->result();
	   else
			return false;
	}
	
	 public function getSignup($custLastName, $custFirstName, $custPhone, $custAddressLine1, $custAddressLine2, $custCity, $custPostalCode, $custCountry, $custCreditLimit,  $custEmail, $custPassword) {

        
        $this->db->query("INSERT INTO `customer`(`custLastName`,`custFirstName`,`custPhone`,`custAddressLine1`,`custAddressLine2`,`custCity`,`custPostalCode`,`custCountry`, `custCreditLimit`,`custEmail`,`custPassword`) VALUES 
		('$custLastName','$custFirstName','$custPhone','$custAddressLine1','$custAddressLine2','$custCity','$custPostalCode','$custCountry', '$custCreditLimit','$custEmail',MD5('$custPassword'))");
        return TRUE;
    }
	function findAll()
    {
        return $this->db->get('product')->result();
    }

    function find($id)
    {
        return $this->db->where('prodCode', $id)->get('product')->row();
    }


    public function insert_order($data)
	{
		$this->db->insert('orders', $data);
		
		$id = $this->db->insert_id();
		
		return (isset($id)) ? $id : FALSE;
	}
	
	public function insert_order_detail($data)
	{
		$this->db->insert('orderdetail', $data);
	}
}
?>
