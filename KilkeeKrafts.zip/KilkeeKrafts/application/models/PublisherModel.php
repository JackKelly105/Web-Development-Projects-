<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class PublisherModel extends CI_Model {

		function __construct() {
        	parent::__construct();
			$this->load->database();
    	}
	
		function get_all_publishers() {
			$this->db->select("PublisherID,PublisherName,AddressLine1,AddressLine2,AddressLine3,ContactName,Image"); 
			$this->db->from('publishers');
			$query = $this->db->get();
			return $query->result();
		}
		
		function drilldown($publisher) {
			$this->db->select("PublisherID,PublisherName,AddressLine1,AddressLine2,AddressLine3,ContactName,Image"); 
			$this->db->from('publishers');
			$this->db->where('PublisherID',$publisher);
			$query = $this->db->get();
			return $query->result();
		}
	}
?>