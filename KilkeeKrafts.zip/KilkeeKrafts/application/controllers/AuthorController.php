<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class AuthorController extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('AuthorModel');
		$this->load->helper('form');
		$this->load->helper('html');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->library('pagination');
		$this->load->library('session');
	}

	function index() {
		//check if the user is already logged in
		if($this->session->userdata('logged_in'))
			//the user is already logged in -> display the index page with secret content
			redirect('AuthorController/Login');
		else
			//user isn't logged in -> display login form
			$this->load->view('Home');
	}
		
	public function listAuthors() 
	{	
		$config['base_url'] = site_url('AuthorController/listAuthors/');
		$config['total_rows'] =$this->AuthorModel->record_count(); 
		$config['per_page']=2;
		$this->pagination->initialize($config);
		$data['author_info']=$this->AuthorModel->get_all_authors(6, $this->uri->segment(3));
		$this->load->view('authorListView',$data);
	}
	
	public function viewAuthor($authorID)
	{	$data['view_data']=$this->AuthorModel->drilldown($authorID);
		$this->load->view('AuthorView',$data);
	}

	public function deleteAuthor($authorID)
	{	$deletedRows = $this->AuthorModel->deleteAuthorModel($authorID);
		if ($deletedRows >0)
			$data['message']="$deletedRows Product has been deleted";
		else
			$data['message']="There was an error deleting the Product with an Code of $authorID";
		$this->load->view('displayMessageView',$data);
	}
	public function editAuthor($authorID)
	{	$data['edit_data']=$this->AuthorModel->drilldown($authorID);
		$this->load->view('updateAuthorView',$data);
	}

	function uploadAndResizeFile() 
	{ //set config options for thumbnail creation 
		$config['upload_path']='./assets/images/products/full/'; 
		$config['allowed_types']='gif|jpg|png'; 
		$config['max_size']='100'; 
		$config['max_width']='1024'; 
		$config['max_height']='768';
		
		$this->load->library('upload',$config); 
		if (!$this->upload->do_upload()) 
			echo $this->upload->display_errors(); 
		else 
			echo 'upload done<br>'; 
		
		$upload_data = $this->upload->data(); 
		$path = $upload_data['full_path']; 
		
		$config['source_image']=$path; 
		$config['maintain_ratio']='FALSE'; 
		$config['width']='180'; 
		$config['height']='200'; 
		
		$this->load->library('image_lib',$config); 
		if (!$this->image_lib->resize()) 
			echo $this->image_lib->display_errors(); 
		else 
			echo 'image resized<br>'; 
		$this->image_lib->clear(); 
		return $path; 
	}
	
	function createThumbnail($path) 
	{ //set config options for thumbnail creation 
		$config['source_image']=$path; 
		$config['new_image']='./assets/images/products/thumbs/'; 
		$config['maintain_ratio']='FALSE'; 
		$config['width']='42'; 
		$config['height']='42'; 
		
		//load library to do the resizing and thumbnail creation 
		$this->image_lib->initialize($config); 
		
		//call function resize in the image library to physiclly create the thumbnail 
		if (!$this->image_lib->resize()) 
			echo $this->image_lib->display_errors(); 
		else 
			echo 'thumbnail created<br>'; }
	
	public function handleInsert(){
		//if the user has submitted the form
		if ($this->input->post('submitInsert')){
			
			$pathToFile = $this->uploadAndResizeFile(); 
			$this->createThumbnail($pathToFile);
			
			//set validation rules
			$this->form_validation->set_rules('ProdCode', 'prodCode', 'required');
			$this->form_validation->set_rules('ProdDescription', 'prodDescription', 'required');
			$this->form_validation->set_rules('ProdCategory', 'prodCategory', 'required');	
			$this->form_validation->set_rules('ProdArtist', 'prodArtist', 'required');
			$this->form_validation->set_rules('ProdQtyInStock', 'prodQtyInStock', 'required');
			$this->form_validation->set_rules('ProdBuyCost', 'prodBuyCost', 'required');
			$this->form_validation->set_rules('ProdSalePrice', 'prodSalePrice', 'required');
			$this->form_validation->set_rules('PriceAlreadyDiscounted', 'priceAlreadyDiscounted', 'required');
			
			//get values from post
			$anAuthor['ProdCode'] = $this->input->post('ProdCode');
			$anAuthor['ProdDescription'] = $this->input->post('ProdDescription');
			$anAuthor['ProdCategory'] = $this->input->post('ProdCategory');
			$anAuthor['ProdArtist'] = $this->input->post('ProdArtist');
			$anAuthor['ProdQtyInStock'] = $this->input->post('ProdQtyInStock');
			$anAuthor['ProdBuyCost'] = $this->input->post('ProdBuyCost');
			$anAuthor['ProdSalePrice'] = $this->input->post('ProdSalePrice');
			$anAuthor['prodPhoto'] = $_FILES['userfile']['name'];
			$anAuthor['PriceAlreadyDiscounted'] = $this->input->post('PriceAlreadyDiscounted');
			
			//check if the form has passed validation
			if (!$this->form_validation->run()){
				//validation has failed, load the form again – keeping all the data in place
				//and pass the appropriate validation error messages via the 
				//form_validation library
				$this->load->view('insertAuthorView', $anAuthor);
				return;
			}

			//check if insert is successful
			if ($this->AuthorModel->insertAuthorModel($anAuthor)) {
				$data['message']="The insert has been successful";
			}
			else {
				$data['message']="Uh oh ... problem on insert";
			}
			
			//load the view to display the message
			$this->load->view('displayMessageView', $data);
			return;
		}

		//the user has not submitted the form
		//initialize the form fields
		$anAuthor['ProdCode'] = "";
		$anAuthor['ProdDescription'] = "";
		$anAuthor['ProdCategory'] = "";
		$anAuthor['ProdArtist'] = "";
		$anAuthor['ProdQtyInStock'] = "";
		$anAuthor['ProdBuyCost'] = "";
		$anAuthor['ProdSalePrice'] = "";
		$anAuthor['PriceAlreadyDiscounted'] = "";

		//load the form
		$this->load->view('insertAuthorView', $anAuthor);
	}
	public function updateAuthor($authorID){
		
		
			
			$pathToFile = $this->uploadAndResizeFile(); 
			$this->createThumbnail($pathToFile);
			
			//set validation rules
			$this->form_validation->set_rules('ProdCode', 'prodCode', 'required');
			$this->form_validation->set_rules('ProdDescription', 'prodDescription', 'required');
			$this->form_validation->set_rules('ProdCategory', 'prodCategory', 'required');	
			$this->form_validation->set_rules('ProdArtist', 'prodArtist', 'required');
			$this->form_validation->set_rules('ProdQtyInStock', 'prodQtyInStock', 'required');
			$this->form_validation->set_rules('ProdBuyCost', 'prodBuyCost', 'required');
			$this->form_validation->set_rules('ProdSalePrice', 'prodSalePrice', 'required');
			$this->form_validation->set_rules('PriceAlreadyDiscounted', 'priceAlreadyDiscounted', 'required');
			
			//get values from post
			$anAuthor['ProdCode'] = $this->input->post('ProdCode');
			$anAuthor['ProdDescription'] = $this->input->post('ProdDescription');
			$anAuthor['ProdCategory'] = $this->input->post('ProdCategory');
			$anAuthor['ProdArtist'] = $this->input->post('ProdArtist');
			$anAuthor['ProdQtyInStock'] = $this->input->post('ProdQtyInStock');
			$anAuthor['ProdBuyCost'] = $this->input->post('ProdBuyCost');
			$anAuthor['ProdSalePrice'] = $this->input->post('ProdSalePrice');
			$anAuthor['prodPhoto'] = $_FILES['userfile']['name'];
			$anAuthor['PriceAlreadyDiscounted'] = $this->input->post('PriceAlreadyDiscounted');
			
			//check if the form has passed validation
			if (!$this->form_validation->run()){
				//validation has failed, load the form again – keeping all the data in place
				//and pass the appropriate validation error messages via the 
				//form_validation library
				$this->load->view('updateAuthorView', $anAuthor);
				return;
			}

			//check if update is successful
			if ($this->AuthorModel->updateAuthorModel($anAuthor, $authorID)) {
				redirect('AuthorController/listAuthors');
			}
			else {
				$data['message']="Uh oh ... problem on update";
			}
			
	
	}
	
	
	function Login() {
		
		if($this->session->userdata('logged_in')) {
		
			$session_data = $this->session->userdata('logged_in');
		
			$data['adminEmail'] = $session_data['adminEmail'];
	
			$this->load->view('index', $data);
		}
		else {
			
			$this->load->view('login_view');
		}
	}
	

	function verify_login() {
		
		$this->form_validation->set_rules('adminEmail', 'AdminEmail', 'trim|required');
		$this->form_validation->set_rules('adminPassword', 'AdminPassword', 'trim|required|callback_check_database');

		if($this->form_validation->run() == false) {
			
			$this->load->view('login_view');
		} else { 
			
			redirect('AuthorController/Login');
		}
	}
	
	
	function check_database($password) {
	
		$username = $this->input->post('adminEmail');
	
	   $result = $this->AuthorModel->login($username, $password);
	  
		if($result) {
			$sess_array = array();
			foreach($result as $row) {
				$sess_array = array(
					'AdminNumber' => $row->adminNumber,
					'adminEmail' => $row->adminEmail
				);
				$this->session->set_userdata('logged_in', $sess_array);				
			}
	
			return true;
		}
		else {
		
			$this->form_validation->set_message('check_database', 'Invalid username or password');
			return false;
		}
	}
	function logout() {

		$this->session->unset_userdata('logged_in');

		$this->session->sess_destroy();

		$this->load->view('Home');
	}
	
	function Home() {
		
			$this->load->view('Home');
	}

	function Search() {

		$prodCode = $this->input->post('prodCode');

    
    $sql = "SELECT * FROM product WHERE prodCode = ?";
	
    
    $query = $this->db->query($sql, array($prodCode));
	
		defined('BASEPATH') OR exit('No direct script access allowed');
		
		$this->load->helper('url');
		$this->load->view('headerSearch');
		$base = base_url() . index_page();
		$img_base = base_url()."assets/images/";
    
    foreach ($query->result() as $row) {
		
      	echo form_open();
		echo '</br></br>';
		
		echo 'Prod Code : ';
		echo form_input('authorID', $row->prodCode, 'readonly');
		
		echo '</br></br>Prod Description : ';
		echo form_input('ProdDescription', $row->prodDescription, 'readonly');

		echo '</br></br>Prod Category : ';
		echo form_input('ProdCategory', $row->prodCategory, 'readonly');

		echo '</br></br>Prod Artist : ';
		echo form_input('ProdArtist', $row->prodArtist, 'readonly');
		
		echo '</br></br>Prod Qty In Stock : ';
		echo form_input('ProdQtyInStock', $row->prodQtyInStock, 'readonly');
		
		echo '</br></br>Prod Buy Cost : ';
		echo form_input('ProdBuyCost', $row->prodBuyCost, 'readonly');
		
		echo '</br></br>Prod Sale Price : ';
		echo form_input('ProdSalePrice', $row->prodSalePrice, 'readonly');

		echo '</br></br>';
		echo '<img src='.$img_base.'products/full/'.$row->prodPhoto.'>';
		
		echo '</br></br>Price Already Discounted : ';
		echo form_input('PriceAlreadyDiscounted', $row->priceAlreadyDiscounted, 'readonly');
		
		echo '</br></br>';
		echo form_close();
		echo anchor('AuthorController/listAuthors', 'List of Products', 'title="List Products"');
		echo '</br></br>';
		echo anchor('AuthorController/deleteAuthor/'.$row->prodCode,
				'Delete', 'onclick="return checkDelete()"');
		echo '</br></br>';
		echo anchor('AuthorController/editAuthor/'.$row->prodCode,
				'Update');
	
		}
    
	}
	
	
}
