<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CustController extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('AuthorModel');
		$this->load->helper('form');
		$this->load->helper('html');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->library('pagination');
		$this->load->library('session');
		
	}
	
	function indexCust() {
		
		if($this->session->userdata('logged_in'))
			
			redirect('CustController/LoginCust');
		else
			
			$this->load->view('Home');
	}

	
	function LoginCust() {
		
		if($this->session->userdata('logged_in')) {
		
			$session_data = $this->session->userdata('logged_in');
		
			$data['custEmail'] = $session_data['custEmail'];
		
			$this->load->view('homecust', $data);
		}
		else {
			
			$this->load->view('Cust_Login');
		}
	}
		
	
	function verify_loginCust() {
		
		$this->form_validation->set_rules('custEmail', 'CustEmail', 'trim|required');
		$this->form_validation->set_rules('custPassword', 'CustPassword', 'trim|required|callback_check_databaseCust');

		if($this->form_validation->run() == false) {
			
			$this->load->view('Cust_Login');
		} else { 
			
			redirect('CustController/LoginCust');
		}
	}
	
	
	function check_databaseCust($password) {
		
		$username = $this->input->post('custEmail');
	
	   $result = $this->AuthorModel->loginCust($username, $password);
	 
		if($result) {
			$sess_array = array();
			foreach($result as $row) {
				$sess_array = array(
					'CustNumber' => $row->custNumber,
					'custEmail' => $row->custEmail
				);
				$this->session->set_userdata('logged_in', $sess_array);				
			}
			
			return true;
		}
		else {
			
			$this->form_validation->set_message('check_databaseCust', 'Invalid username or password');
			return false;
		}
	}
	
	function logoutCust() {
		
		$this->session->unset_userdata('logged_in');
		
		$this->session->sess_destroy();
		
		$this->load->view('Home');
	}
	
	function homecust() {
		
			$this->load->view('homecust');
	}
	
	public function reg() {

        $this->form_validation->set_rules('custLastName', 'Last Name', 'trim|required|max_length[50]');
		$this->form_validation->set_rules('custFirstName', 'First Name', 'trim|required|max_length[50]');
		$this->form_validation->set_rules('custPhone', 'Phone', 'trim|required|max_length[50]');
		$this->form_validation->set_rules('custAddressLine1', 'Address Line 1', 'trim|required|max_length[50]');
		$this->form_validation->set_rules('custAddressLine2', 'Address Line 2', 'trim|max_length[50]');
		$this->form_validation->set_rules('custCity', 'City', 'trim|required|max_length[50]');
		$this->form_validation->set_rules('custPostalCode', 'Postal Code', 'trim|max_length[15]');
		$this->form_validation->set_rules('custCountry', 'Country', 'trim|required|max_length[50]');
		$this->form_validation->set_rules('custCreditLimit', 'Credit Limit', 'trim|max_length[50]');
        $this->form_validation->set_rules('custPassword', 'Password', 'trim|required|min_length[6]');
        $this->form_validation->set_rules('custEmail', 'Email', 'trim|required|valid_email|is_unique[customer.custEmail]');
       $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|matches[custPassword]');
        if ($this->form_validation->run() == FALSE) {
            $this->Register();
        } else {

            $custLastName = $this->input->post("custLastName");
            $custFirstName = $this->input->post("custFirstName");
            $custPhone = $this->input->post("custPhone");
            $custAddressLine1 = $this->input->post("custAddressLine1");
			$custAddressLine2 = $this->input->post("custAddressLine2");
			$custCity = $this->input->post("custCity");
			$custPostalCode = $this->input->post("custPostalCode");
			$custCountry = $this->input->post("custCountry");
			$custCreditLimit = $this->input->post("custCreditLimit");
			$custEmail = $this->input->post("custEmail");
			$custPassword = $this->input->post("custPassword");
			
          
            $isDone = $this->AuthorModel->getSignup($custLastName,$custFirstName, $custPhone, $custAddressLine1,$custAddressLine2,$custCity,$custPostalCode,$custCountry,$custCreditLimit,$custEmail,$custPassword);

            if ($isDone === TRUE) {
                $this->load->view('Home');
            }
        }
    }
	function Register() {
		
			$this->load->view('register_view');
	}
	
	public function listAuthors() 
	{	
		$config['base_url'] = site_url('CustController/listAuthors/');
		$config['total_rows'] =$this->AuthorModel->record_count(); 
		$config['per_page']=2;
		$this->pagination->initialize($config);
		$data['author_info']=$this->AuthorModel->get_all_authors(6, $this->uri->segment(3));
		$this->load->view('custListView',$data);
	}
	
	public function viewAuthor($authorID)
	{	$data['view_data']=$this->AuthorModel->drilldown($authorID);
		$this->load->view('custView',$data);
	}


	function createThumbnail($path) 
	{ //set config options for thumbnail creation 
		$config['source_image']=$path; 
		$config['new_image']='./assets/images/products/thumbs/'; 
		$config['maintain_ratio']='FALSE'; 
		$config['width']='42'; 
		$config['height']='42'; 
		
		//load library to do the resizing and thumbnail creation 
		$this->image_lib->initialize($config); 
		
		//call function resize in the image library to physiclly create the thumbnail 
		if (!$this->image_lib->resize()) 
			echo $this->image_lib->display_errors(); 
		else 
			echo 'thumbnail created<br>'; }
			
	function Search() {

		$prodCode = $this->input->post('prodCode');

    
    $sql = "SELECT * FROM product WHERE prodCode = ?";
	
    
    $query = $this->db->query($sql, array($prodCode));
	
		defined('BASEPATH') OR exit('No direct script access allowed');
		
		$this->load->helper('url');
		$this->load->view('custHeaderSearch');
		$base = base_url() . index_page();
		$img_base = base_url()."assets/images/";
    
    foreach ($query->result() as $row) {
		
      	echo form_open();
		echo '</br></br>';
		
		echo 'Prod Code : ';
		echo form_input('authorID', $row->prodCode, 'readonly');
		
		echo '</br></br>Prod Description : ';
		echo form_input('ProdDescription', $row->prodDescription, 'readonly');

		echo '</br></br>Prod Category : ';
		echo form_input('ProdCategory', $row->prodCategory, 'readonly');

		echo '</br></br>Prod Artist : ';
		echo form_input('ProdArtist', $row->prodArtist, 'readonly');
		
		echo '</br></br>Prod Qty In Stock : ';
		echo form_input('ProdQtyInStock', $row->prodQtyInStock, 'readonly');
		
		echo '</br></br>Prod Buy Cost : ';
		echo form_input('ProdBuyCost', $row->prodBuyCost, 'readonly');
		
		echo '</br></br>Prod Sale Price : ';
		echo form_input('ProdSalePrice', $row->prodSalePrice, 'readonly');

		echo '</br></br>';
		echo '<img src='.$img_base.'products/full/'.$row->prodPhoto.'>';
		
		echo '</br></br>Price Already Discounted : ';
		echo form_input('PriceAlreadyDiscounted', $row->priceAlreadyDiscounted, 'readonly');
		
		echo '</br></br>';
		echo form_close();
		echo anchor('CustController/listAuthors', 'List of Products', 'title="List Products"');
	
		}
    
	}
	
	
}
