<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Cart extends CI_Controller
{
	public function __construct(){
		parent::__construct();
		$this->load->model('AuthorModel');
		$this->load->helper('form');
		$this->load->helper('html');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->library('pagination');
		$this->load->library('session');
		
	}

    public function index()
    {
        $data['items'] = array_values(unserialize($this->session->userdata('cart')));
        $data['total'] = $this->total();
        $this->load->view('cartView', $data);
    }

    public function buy($id)
    {
        $product = $this->AuthorModel->find($id);
        $item = array(
            'prodCode' => $product->prodCode,
            'prodDescription' => $product->prodDescription,
            'prodSalePrice' => $product->prodSalePrice,
			'prodPhoto' => $product->prodPhoto,
            'quantity' => 1
        );
        if(!$this->session->has_userdata('cart')) {
            $cart = array($item);
            $this->session->set_userdata('cart', serialize($cart));
        } else {
            $index = $this->exists($id);
            $cart = array_values(unserialize($this->session->userdata('cart')));
            if($index == -1) {
                array_push($cart, $item);
                $this->session->set_userdata('cart', serialize($cart));
            } else {
                $cart[$index]['quantity']++;
                $this->session->set_userdata('cart', serialize($cart));
            }
        }
        redirect('cart');
    }

    public function remove($id)
    {
        $index = $this->exists($id);
        $cart = array_values(unserialize($this->session->userdata('cart')));
        unset($cart[$index]);
        $this->session->set_userdata('cart', serialize($cart));
        redirect('cart');
    }

    private function exists($id)
    {
        $cart = array_values(unserialize($this->session->userdata('cart')));
        for ($i = 0; $i < count($cart); $i ++) {
            if ($cart[$i]['prodCode'] == $id) {
                return $i;
            }
        }
        return -1;
		
    }

    private function total() {
        $items = array_values(unserialize($this->session->userdata('cart')));
        $s = 0;
        foreach ($items as $item) {
            $s += $item['prodSalePrice'] * $item['quantity'];
        }
        return $s;
		
    }
	
	public function save_order($id)
	{
		$logged_in = $this->session->userdata('logged_in');
		$createdby = $logged_in['CustNumber'];
		
		 $product = $this->AuthorModel->find($id);
			$item = array(
            'prodCode' => $product->prodCode,
            'prodDescription' => $product->prodDescription,
            'prodSalePrice' => $product->prodSalePrice,
			'prodPhoto' => $product->prodPhoto,
            'quantity' => 1
        );
		
		$order = array(
			'oOrderDate' 			=> date('Y-m-d'),
			'oRequiredDate' 		=> date('Y-m-d', strtotime("+7 day")),
			'oShippedDate' 			=> NULL,
			'oStatus' 			=> ('Not Shipped'),
			'oComments' 			=> ('no comment'),
			'oCustomerNumber' 	=> ($createdby)
		);		

		$ord_id = $this->AuthorModel->insert_order($order);
		
	
				$order_detail = array(
					'odOrderNumber' 		=> $ord_id,
					'odProductCode' 	=> $item['prodCode'],
					'odQuantityOrdered' => $item['quantity'],
					'odPrice' 		=> $item['prodSalePrice']
				);		

				$id = $this->AuthorModel->insert_order_detail($order_detail);

		
		echo "Thank You! your order has been placed!<br />";
		echo "<a href=".base_url()."index.php/cart>Go back</a>";
	}
	
}