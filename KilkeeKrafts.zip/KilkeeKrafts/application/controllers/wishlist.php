<?php
defined('BASEPATH') or exit('No direct script access allowed');

class wishlist extends CI_Controller
{
	public function __construct(){
		parent::__construct();
		$this->load->model('AuthorModel');
		$this->load->helper('form');
		$this->load->helper('html');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->library('pagination');
		$this->load->library('session');
		
	}

    public function index()
    {
        $data['items'] = array_values(unserialize($this->session->userdata('wishlist')));
        $data['total'] = $this->total();
        $this->load->view('wishListView', $data);
    }

    public function buy($id)
    {
        $product = $this->AuthorModel->find($id);
        $item = array(
            'prodCode' => $product->prodCode,
            'prodDescription' => $product->prodDescription,
            'prodSalePrice' => $product->prodSalePrice,
			'prodPhoto' => $product->prodPhoto,
            'quantity' => 1
        );
        if(!$this->session->has_userdata('wishlist')) {
            $cart = array($item);
            $this->session->set_userdata('wishlist', serialize($cart));
        } else {
            $index = $this->exists($id);
            $cart = array_values(unserialize($this->session->userdata('wishlist')));
            if($index == -1) {
                array_push($cart, $item);
                $this->session->set_userdata('wishlist', serialize($cart));
            } else {
                $cart[$index]['quantity']++;
                $this->session->set_userdata('wishlist', serialize($cart));
            }
        }
        redirect('wishlist');
    }

    public function remove($id)
    {
        $index = $this->exists($id);
        $cart = array_values(unserialize($this->session->userdata('wishlist')));
        unset($cart[$index]);
        $this->session->set_userdata('wishlist', serialize($cart));
        redirect('wishlist');
    }

    private function exists($id)
    {
        $cart = array_values(unserialize($this->session->userdata('wishlist')));
        for ($i = 0; $i < count($cart); $i ++) {
            if ($cart[$i]['prodCode'] == $id) {
                return $i;
            }
        }
        return -1;
    }

    private function total() {
        $items = array_values(unserialize($this->session->userdata('wishlist')));
        $s = 0;
        foreach ($items as $item) {
            $s += $item['prodSalePrice'] * $item['quantity'];
        }
        return $s;
    }
}