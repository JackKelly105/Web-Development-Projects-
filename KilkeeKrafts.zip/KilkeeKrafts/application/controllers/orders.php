<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Orders extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('AuthorModel');
		$this->load->helper('form');
		$this->load->helper('html');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->library('pagination');
		$this->load->library('session');
	}

	function index() {
		//check if the user is already logged in
		if($this->session->userdata('logged_in'))
			//the user is already logged in -> display the index page with secret content
			redirect('AuthorController/Login');
		else
			//user isn't logged in -> display login form
			$this->load->view('Home');
	}
		
	public function listAuthors() 
	{	
		$config['base_url'] = site_url('orders/listAuthors/');
		$config['total_rows'] =$this->AuthorModel->record_countOrders(); 
		$config['per_page']=2;
		$this->pagination->initialize($config);
		$data['author_info']=$this->AuthorModel->get_all_orders(6, $this->uri->segment(3));
		$this->load->view('orderlistView',$data);
	}
	
	public function listOrderDetails() 
	{	
		$config['base_url'] = site_url('orders/listOrderDetails/');
		$config['total_rows'] =$this->AuthorModel->record_countOrders(); 
		$config['per_page']=2;
		$this->pagination->initialize($config);
		$data['author_info']=$this->AuthorModel->get_all_orders_details(6, $this->uri->segment(3));
		$this->load->view('orderDetailListView',$data);
	}
	
	public function viewAuthor($authorID)
	{	$data['view_data']=$this->AuthorModel->drilldownOrders($authorID);
		$this->load->view('orderView',$data);
	}
	
	public function viewOrderDetails($authorID)
	{	$data['view_data']=$this->AuthorModel->drilldownOrderDetails($authorID);
		$this->load->view('orderDetailView',$data);
	}

	public function deleteAuthor($authorID)
	{	$deletedRows = $this->AuthorModel->deleteOrderModel($authorID);
		if ($deletedRows >0)
			$data['message']="$deletedRows Order has been deleted";
		else
			$data['message']="There was an error deleting the order with a number of $authorID";
		$this->load->view('displayMessageView',$data);
	}
	public function editAuthor($authorID)
	{	$data['edit_data']=$this->AuthorModel->drilldownOrders($authorID);
		$this->load->view('updateOrderView',$data);
	}


	public function updateAuthor($authorID){
		
		
			
			//set validation rules
			$this->form_validation->set_rules('OOrderNumber', 'oOrderNumber', 'required');
			$this->form_validation->set_rules('OOrderDate', 'oOrderDate', 'required');
			$this->form_validation->set_rules('ORequiredDate', 'oRequiredDate', 'required');	
			$this->form_validation->set_rules('OShippedDate', 'oShippedDate', 'required');
			$this->form_validation->set_rules('OStatus', 'oStatus', 'required');
			$this->form_validation->set_rules('OComments', 'oComments', 'required');
			$this->form_validation->set_rules('OCustomerNumber', 'oCustomerNumber', 'required');
			
			//get values from post
			$anAuthor['OOrderNumber'] = $this->input->post('OOrderNumber');
			$anAuthor['OOrderDate'] = $this->input->post('OOrderDate');
			$anAuthor['ORequiredDate'] = $this->input->post('ORequiredDate');
			$anAuthor['OShippedDate'] = $this->input->post('OShippedDate');
			$anAuthor['OStatus'] = $this->input->post('OStatus');
			$anAuthor['OComments'] = $this->input->post('OComments');
			$anAuthor['OCustomerNumber'] = $this->input->post('OCustomerNumber');
			
			//check if the form has passed validation
			if (!$this->form_validation->run()){
				//validation has failed, load the form again – keeping all the data in place
				//and pass the appropriate validation error messages via the 
				//form_validation library
				$this->load->view('updateOrderViewView', $anAuthor);
				return;
			}

			//check if update is successful
			if ($this->AuthorModel->updateOrdersModel($anAuthor, $authorID)) {
				redirect('orders/listAuthors');
			}
			else {
				$data['message']="Uh oh ... problem on update";
			}
			
	
	}
	
	function Home() {
		
			$this->load->view('Home');
	}

	function Search() {

		$oOrderNumber = $this->input->post('oOrderNumber');

    
    $sql = "SELECT * FROM orders WHERE oOrderNumber = ?";
	
    
    $query = $this->db->query($sql, array($oOrderNumber));
	
		defined('BASEPATH') OR exit('No direct script access allowed');
		
		$this->load->helper('url');
		$this->load->view('headerSearch');
		$base = base_url() . index_page();
		$img_base = base_url()."assets/images/";
    
    foreach ($query->result() as $row) {
		
      	echo form_open();
		echo '</br></br>';
		
		echo 'Order Number : ';
		echo form_input('authorID', $row->oOrderNumber, 'readonly');
		
		echo '</br></br>Order Date : ';
		echo form_input('OOrderDate', $row->oOrderDate, 'readonly');

		echo '</br></br>Required Date : ';
		echo form_input('ORequiredDate', $row->oRequiredDate, 'readonly');

		echo '</br></br>Shipped Date : ';
		echo form_input('OShippedDate', $row->oShippedDate, 'readonly');
		
		echo '</br></br>Status : ';
		echo form_input('OStatus', $row->oStatus, 'readonly');
		
		echo '</br></br>Comments : ';
		echo form_input('OComments', $row->oComments, 'readonly');
		
		echo '</br></br>Customer Number : ';
		echo form_input('OCustomerNumber', $row->oCustomerNumber, 'readonly');

		echo '</br></br>';
		echo form_close();
		echo anchor('orders/listAuthors', 'List of Orders', 'title="List Products"');
		echo '</br></br>';
		echo anchor('orders/deleteAuthor/'.$row->oOrderNumber,
				'Delete', 'onclick="return checkDelete()"');
		echo '</br></br>';
		echo anchor('orders/editAuthor/'.$row->oOrderNumber,
				'Update');
	
		}
    
	}
	
	function SearchOrderDetail() {

		$odOrderNumber = $this->input->post('odOrderNumber');

    
    $sql = "SELECT * FROM orderdetail WHERE odOrderNumber = ?";
	
    
    $query = $this->db->query($sql, array($odOrderNumber));
	
		defined('BASEPATH') OR exit('No direct script access allowed');
		
		$this->load->helper('url');
		$this->load->view('headerSearch');
		$base = base_url() . index_page();
		$img_base = base_url()."assets/images/";
    
    foreach ($query->result() as $row) {
		
      	echo form_open();
		echo '</br></br>';
		
		echo 'Order Number : ';
		echo form_input('authorID', $row->odOrderNumber, 'readonly');
		
		echo '</br></br>Product Code : ';
		echo form_input('ODProductCode', $row->odProductCode, 'readonly');

		echo '</br></br>Quantity Ordered : ';
		echo form_input('ODQuantityOrdered', $row->odQuantityOrdered, 'readonly');

		echo '</br></br>Price : ';
		echo form_input('ODPrice', $row->odPrice, 'readonly');
		
		echo '</br></br>';
		echo form_close();
		echo anchor('orders/listOrderDetails', 'Order Details', 'title="Order Details"');
	
		}
    
	}
	
}
